Homework 02 - Blog Website

Website opens to homepage, which lists all of the posts.

    - homepage
        - On the left side, there are buttons to go to the homepage, the create post page, and each of the posts detail pages

        - Posts have a hover functionality and, if clicked, will take you to post details

    - create post
        - i didn't use the tinymce textarea because it wouldn't let me type in the textbox, so i just used bootstrap instead (it works).

        - all fields must be filled and the title must be unique in order for the create post button to work

        - when info is added into all of the text boxes, click the create post button to create the post and add it to the list of posts.

    - post details
        - shows category, then title, then post article, then the date posted in m/d/yyyy format.

        - below is a delete post button, which will delete the post.
